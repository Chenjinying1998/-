package cn.tw.domain;

public class Bedroom {
	private String bedroomId;
	private String apartmentId;
	private String bedroomName;
	private String status;
	private String totalBed;
	public String getBedroomId() {
		return bedroomId;
	}
	public void setBedroomId(String bedroomId) {
		this.bedroomId = bedroomId;
	}
	public String getApartmentId() {
		return apartmentId;
	}
	public void setApartmentId(String apartmentId) {
		this.apartmentId = apartmentId;
	}
	public String getBedroomName() {
		return bedroomName;
	}
	public void setBedroomName(String bedroomName) {
		this.bedroomName = bedroomName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTotalBed() {
		return totalBed;
	}
	public void setTotalBed(String totalBed) {
		this.totalBed = totalBed;
	}
	
}
