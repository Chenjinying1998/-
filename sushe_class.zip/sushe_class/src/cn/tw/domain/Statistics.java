package cn.tw.domain;

public class Statistics {

}
