package cn.tw.domain;

public class Classes {

	private String classId;
	private String className;
	private String coach;
	private String coachCall;
	private String collegeId;
	private String grade;

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getCoach() {
		return coach;
	}

	public void setCoach(String coach) {
		this.coach = coach;
	}

	public String getCoachCall() {
		return coachCall;
	}

	public void setCoachCall(String coachCall) {
		this.coachCall = coachCall;
	}

	public String getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(String collegeId) {
		this.collegeId = collegeId;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

}
