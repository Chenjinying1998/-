package cn.tw.service;

import java.util.Map;

public interface StatisticsService {

	public void updateStuBrByCla(Map map);
	
}
